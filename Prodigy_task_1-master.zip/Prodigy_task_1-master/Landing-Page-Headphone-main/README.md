## Responsive Landing Page Headphones 🎧

- Beautiful headphone landing page using HTML, CSS and JAVASCRIPT.
- Dark interface.
- With animations when scrolling.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

![preview](https://github.com/TiagoCoder2022/Landing-Page-Headphone/assets/119512258/6d455623-3b5b-4f53-aac6-32d432f2a317)

 credits: [Watch it on youtube](https://youtu.be/wXnlHIvKnTM)
